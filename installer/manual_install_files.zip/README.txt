This ZIP file contains all of the files needed to manually install Graphyx. Installing Graphyx manually implies acceptance of the license agreement in License.rtf.

To install Graphyx manually:

1. Copy the Neo4jDelete, Neo4jInput, and Neo4jOutput folders to Alteryx's custom tool folder. To install for all users, use the global folder (typically C:\ProgramData\Alteryx\Tools). To install for a specific user, use the user-specific folder (typically C:\Users\YOUR-USERNAME\AppData\Roaming\Alteryx\Tools)

2. Copy graphyx.dll to Alteryx's Plugins folder (typically "C:\Program Files\Alteryx\bin\Plugins" for admin installs or "C:\Users\YOUR-USERNAME\AppData\Local\Alteryx\bin\Plugins" for non-admin installs).